/*
 * BUZZER TONE UTILITY
 * Author: Kalil Cabral
 * Version: 2
 * License: MIT
 */

#include "buzzer_tone.h"

#define TIMER_CLOCK 80000000 // 80 MHz

uint32_t calculate_period(float, uint32_t);
void set_timer_period(Buzzer *, uint32_t);

void buzzerTone_Play(Buzzer *zz, float frequency) {
  /*
   * XXX: The ideal approach would be to calculate the prescaler value in a way
   *      that generates the most accurate frequency possible and then change it
   *      every time the timer is reinited, but I don't know how to approach
   *      that, so we're just using whatever's been configured previously.
   */
  uint32_t prescaler = zz->htim->Init.Prescaler;
  set_timer_period(zz, calculate_period(frequency, prescaler));
  HAL_TIM_Base_Start_IT(zz->htim);
}

void buzzerTone_PlayNote(Buzzer *zz, enum Notes note) {
  switch (note) {
  case NOTE_C:
    buzzerTone_Play(zz, 261.63);
    break;
  case NOTE_C_SHARP:
  case NOTE_D_FLAT:
    buzzerTone_Play(zz, 277.18);
    break;
  case NOTE_D:
    buzzerTone_Play(zz, 293.66);
    break;
  case NOTE_D_SHARP:
  case NOTE_E_FLAT:
    buzzerTone_Play(zz, 311.13);
    break;
  case NOTE_E:
    buzzerTone_Play(zz, 329.63);
    break;
  case NOTE_F:
    buzzerTone_Play(zz, 349.23);
    break;
  case NOTE_F_SHARP:
  case NOTE_G_FLAT:
    buzzerTone_Play(zz, 369.99);
    break;
  case NOTE_G:
    buzzerTone_Play(zz, 392.00);
    break;
  case NOTE_G_SHARP:
  case NOTE_A_FLAT:
    buzzerTone_Play(zz, 415.30);
    break;
  case NOTE_A:
    buzzerTone_Play(zz, 440.00);
    break;
  case NOTE_A_SHARP:
  case NOTE_B_FLAT:
    buzzerTone_Play(zz, 466.16);
    break;
  case NOTE_B:
    buzzerTone_Play(zz, 493.88);
    break;
  }
}

void buzzerTone_Pause(Buzzer *zz) { HAL_TIM_Base_Stop_IT(zz->htim); }

void buzzerTone_IRQHandler(Buzzer *zz) {
  HAL_GPIO_TogglePin(zz->port, zz->pin);
}

void set_timer_period(Buzzer *zz, uint32_t period) {
  if (zz->htim->Init.Period != period) {
    HAL_TIM_Base_DeInit(zz->htim);
    zz->htim->Init.Period = period;
    HAL_TIM_Base_Init(zz->htim);
  }
}

uint32_t calculate_period(float target_freq, uint32_t prescaler_value) {
  /*
   * The actual note emitted by the buzzer has half of the frequency of the
   * clock (timeout) frequency, because the period of the square wave we're
   * sending to the buzzer is two timeouts (one to toggle the pin high and the
   * second to turn the pin low). Therefore
   *    TIMER_FREQUENCY = 2 * TARGET_FREQUENCY
   * The formula for the actual timer frequency is
   *    TIMER_CLOCK / ((PRESCALER + 1) * (PERIOD + 1)) = TIMER_FREQUENCY
   * Therefore
   *    TIMER_CLOCK = TIMER_FREQUENCY * (PRESCALER + 1) * (PERIOD + 1)
   *    TIMER_CLOCK / (TIMER_FREQUENCY * (PRESCALER + 1)) = PERIOD + 1
   *    (TIMER_CLOCK / (TIMER_FREQUENCY * (PRESCALER + 1))) - 1 = PERIOD
   * Which results in
   *    (TIMER_CLOCK / (2 * TARGET_FREQUENCY * (PRESCALER + 1))) - 1
   */
  return (int)(TIMER_CLOCK / (2 * target_freq * (prescaler_value + 1))) - 1;
}