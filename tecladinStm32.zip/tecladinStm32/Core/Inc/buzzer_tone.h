/*
 * BUZZER TONE UTILITY
 * Author: Kalil Cabral
 * Version: 2
 * License: MIT
 *
 * Uses a timer to play specific musical notes in a passive buzzer.
 *
 * -> Requires a preconfigured GPIO pin and timer. The GPIO pin should be
 *    connected to the buzzer.
 * -> Make sure the timer configuration supports the frequency
 *    of the notes you want to play.
 * -> The IRQHandler function must be manually called from the timer's
 *    interrupt routine.
 */

#ifndef __USER_BUZZER_TONE
#define __USER_BUZZER_TONE

#include "stm32l4xx_hal.h"

typedef struct Buzzer {
  TIM_HandleTypeDef *htim;
  GPIO_TypeDef *port;
  uint16_t pin;
} Buzzer;

enum Notes {
  NOTE_C,
  NOTE_C_SHARP,
  NOTE_D_FLAT,
  NOTE_D,
  NOTE_D_SHARP,
  NOTE_E_FLAT,
  NOTE_E,
  NOTE_F,
  NOTE_F_SHARP,
  NOTE_G_FLAT,
  NOTE_G,
  NOTE_G_SHARP,
  NOTE_A_FLAT,
  NOTE_A,
  NOTE_A_SHARP,
  NOTE_B_FLAT,
  NOTE_B,
};

// Handles timer interrupts
void buzzerTone_IRQHandler(Buzzer *);

// Plays a frequency
void buzzerTone_Play(Buzzer *, float);

// Plays a specific note
void buzzerTone_PlayNote(Buzzer *, enum Notes);

// Stops the buzzer
void buzzerTone_Pause(Buzzer *);

#endif // __USER_BUZZER_TONE